library(NBDiagnostics)

## simulate a dataset with outcome and baseline count
obs <- 200
s <- rgamma(obs, shape = 1/3, scale = 3)
y0 <- rpois(obs, 25 * s)
x <- rep(c(1, 0), each=obs/2)
y1 <- rpois(obs, 25 * s * exp(-0.7 * x))
x <- factor(x, levels = c(1, 0),
            labels = c('Intervention', 'Control'))
dat <- data.frame(id=1:obs, y0=y0, y1=y1, group=x)

## fit an NB model using nbdiagnostics() and specify
## the varaibles names for the plots
mod_nb <- nbdiagnostics(
  y1 ~ group, data=dat, id_varname = "id",
  followup_varname="y1", baseline_varname="y0",
  group_varname = "group")

## produce the baseline/outcome event plots
boeplot(mod_nb, diagnostic_stat = "cookd")
boeplot(mod_nb, diagnostic_stat = "leverage")
boeplot(mod_nb, diagnostic_stat = "anscombe_resid")
boeplot(mod_nb, diagnostic_stat = "dfbeta")

## covariate adjusted probability plots (Holling et al, 2016)
caprob_nb(20, mod_nb)
caprob_nb_poi(20, mod_nb, data=dat)
